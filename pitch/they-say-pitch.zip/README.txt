They Say / GroundTruth pitch package

- GroundTruth-Pitch-Deck.pptx : 10-slide pitch deck (also provided separately)
- reports/ : system architecture proposal + hummingbird 1:4 trace
- source/ : README, graph schema, ingestion/build scripts, frontend viz

Live demo: https://rowan121.github.io/they-say/
Repo: https://github.com/Rowan121/they-say
